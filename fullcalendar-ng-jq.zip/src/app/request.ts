export class Request {
  constructor(
      /*public data: any,
      public status: any*/
  ) {}
}